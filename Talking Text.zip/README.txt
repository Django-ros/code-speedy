Packet Name:- Talking Text

Current Problem: Long passages and articles are better heard than read.

Proposed Solution: A text to speech converter that can be present on any website.

Functions of the packet: It has 2 basic functions
1. Read the provided text in different languages and accents.
2. Change the Speed and Pitch of the voice in which text is being read

Content of the zip: This is a code packet containing two files
1. talk.js: Containing the JavaScript, CSS and HTML.
3. demo.HTML: A demo of how the box would work without further customization.
4. README

How to Use: It involves just 2 steps (look at the demo.HTML first and hover over the scrollbar)
1. Download and add the the file (talk.js) to the same folder as index.HTML of your file
2. Make a new div with the id of "deploy" , this would be the wrapper.
3. Add the given lines to the bottom of body tag
<script src="talk.js"></script>

Made by: Aishwarya Agrawal